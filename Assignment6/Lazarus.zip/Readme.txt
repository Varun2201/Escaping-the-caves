hintconv.py converts the hexadecimal code to text.

attack.sage recovers the password from the given ciphertext.
To run sage file command - sage attack.sage on the colac terminal

attack.ipynb contains the same code as attack.sage but in jupyternotebook format.To be run with sagemath 9.5 kernel.
