Steps to Run Assignment

In Command Prompt/ Terminal Type:

1. make run         
